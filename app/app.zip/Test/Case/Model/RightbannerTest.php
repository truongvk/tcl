<?php
App::uses('Rightbanner', 'Model');

/**
 * Rightbanner Test Case
 *
 */
class RightbannerTestCase extends CakeTestCase {
/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array('app.rightbanner');

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->Rightbanner = ClassRegistry::init('Rightbanner');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->Rightbanner);

		parent::tearDown();
	}

}
