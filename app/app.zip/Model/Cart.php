<?php
App::uses('AppModel', 'Model');
/**
 * Cart Model
 *
 * @property Cart $Cart
 */
class Cart extends AppModel {
    public $useTable = false;
}
?>
