<?php
class GlobalConfig extends AppModel {
    var $useTable = false;
}
?>
