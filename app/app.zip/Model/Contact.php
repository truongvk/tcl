<?php

App::uses('AppModel', 'Model');

/**
 * Contact Model
 *
 */
class Contact extends AppModel {

    /**
     * Validation rules
     *
     * @var array
     */
    public $validate = array(
        'name' => array(
            'notempty' => array(
                'rule' => array('notempty'),
            //'message' => 'Your custom message here',
            //'allowEmpty' => false,
            //'required' => false,
            //'last' => false, // Stop validation after this rule
            //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
        ),
        'email' => array(
            'notempty' => array(
                'rule' => array('notempty')
            ),
            'email' => array(
                'rule' => array('email'),
            //'message' => 'Your custom message here',
            //'allowEmpty' => false,
            //'required' => false,
            //'last' => false, // Stop validation after this rule
            //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
        ),
        'title' => array(
            'notempty' => array(
                'rule' => array('notempty'),
            //'message' => 'Your custom message here',
            //'allowEmpty' => false,
            //'required' => false,
            //'last' => false, // Stop validation after this rule
            //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
        ),
        'content' => array(
            'notempty' => array(
                'rule' => array('notempty'),
            //'message' => 'Your custom message here',
            //'allowEmpty' => false,
            //'required' => false,
            //'last' => false, // Stop validation after this rule
            //'on' => 'create', // Limit validation to 'create' or 'update' operations
            ),
        ),
    );
    
    public function beforeValidate($options = array()) {
        parent::beforeValidate($options);
        
        $this->validate['name']['notempty']['message'] = __('Name cannot be null');
        $this->validate['title']['notempty']['message'] = __('Title cannot be null');
        $this->validate['content']['notempty']['message'] = __('Content cannot be null');
        $this->validate['email']['notempty']['message'] = __('Email cannot be null');
        $this->validate['email']['email']['message'] = __('Email invalid');
    }

}
