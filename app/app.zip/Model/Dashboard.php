<?php

App::uses('AppModel', 'Model');

class Dashboard extends AppModel {
  public $useTable = false;
}
