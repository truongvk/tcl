/* generated user stylesheet */
a.new, #quickbar a.new { color: #CC2200; }
