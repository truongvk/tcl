<?php
$config['Settings'] = array(
'domain' => array('value'=>'tclvn.com','desc'=>'your domain','priority'=>'0'),
'admin_email' => array('value'=>'vukhanhtruong@gmail.com\r\nkenghiemdo@gmail.com','desc'=>'dia chi email se duoc gui khi co thong tin tu khach hang','priority'=>'0'),
'contact_email' => array('value'=>'contact@tclvn.com ','desc'=>'email lien he','priority'=>'0'),
'contact_phone' => array('value'=>'1-888-888-6688','desc'=>'so dien thoai lien he','priority'=>'0'),
'support_by_yahoo' => array('value'=>'khanhtruong111@yahoo.com','desc'=>'ho tro khach hang qua nick yahoo','priority'=>'0'),
'support_by_skype' => array('value'=>'khanhtruong111','desc'=>'ho tro khach hang qua nick skype','priority'=>'0'),
'num_of_promotion_products' => array('value'=>'4','desc'=>'so luong san pham khuyen mai muon hien thi','priority'=>'0'),
'num_of_latest_products' => array('value'=>'6','desc'=>'so luong san pham moi muon hien thi','priority'=>'0'),
'expand_collapse_attributes' => array('value'=>'20','desc'=>'so luong filter muon hien thi','priority'=>'0'),
'footer_about_us' => array('value'=>'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.','desc'=>'about us','priority'=>'0'),
);
?>