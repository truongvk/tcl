<?php

App::uses('AclManagementAppModel', 'AclManagement.Model');

/**
 * UserPermission Model
 *
 * @property UserPermission $UserPermission
 */
class UserPermission extends AclManagementAppModel {
    public $useTable = false; 
}
