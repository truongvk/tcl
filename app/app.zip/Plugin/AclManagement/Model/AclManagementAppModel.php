<?php
class AclManagementAppModel extends AppModel {

}
?>