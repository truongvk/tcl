<?php

class AclManagementAppController extends AppController {

}
?>